﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, SalirToolStripMenuItem1.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Conversor Grados"
        Label2.Text = "Celsius"
        Label3.Text = "Farenheit"
        Button2.Text = "Convertir a Farenheit"
        Button3.Text = "Convertir a Celsius"

        Label4.Text = "Input Box"
        Label5.Text = "Nombre"
        Label6.Text = "Edad"
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        Button4.Text = "Procesar"

        Label7.Text = "Menús"
        PruebaToolStripMenuItem.Text = "Cambio el Nombre de una opcion de menu"

        Label8.Text = "Ratón"
        iniciar_raton()

        Label9.Text = "Editor"
        Label10.Text = "Palabra"
        Label11.Text = "Texto"
        RichTextBox2.ReadOnly = True
        Button8.Text = "Aceptar"
        Button9.Text = "Limpiar"
        Button10.Text = "Limpiar"
        Button11.Text = "All"
        Button12.Text = "Foco"

        Label12.Text = "Caracteres:"
        Label14.Text = "Selecionados:"

        Label16.Text = "Controles"
        Button13.Text = "Red Label"
        Button14.Text = "Green Box"
        Button15.Text = "Blue Botton"
        Button16.Text = "Borrar Item y Crear Nuevo"

        Label17.Text = "GroupBox y RadioGroup"

        Label18.Text = "ListBox"
        Button17.Text = "Limpiar"
        Button18.Text = "Agregar"
        Button19.Text = "Buscar"
        Button20.Text = "Traspasar"
        Button21.Text = "Seleccionar por codigo"

        ListBox1.SelectionMode = SelectionMode.None
        RichTextBox3.ReadOnly = True

        Label19.Text = "ComboBox"
        Button22.Text = "Agregar Valores"
        Button23.Text = "Añadir Valor"
        Button24.Text = "Eliminar Valor"
        Button25.Text = "Mostrar Valor"

    End Sub






    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim t As Integer
        If TextBox1.TextLength = 0 Then
            MsgBox("Mete Algo .... capullin")
        Else
            Try
                t = Convert.ToInt16(TextBox1.Text)
            Catch ex As Exception
                MsgBox("Mete numeros zopenco")
            End Try
        End If
        If t <> 0 Then
            TextBox2.Text = ((t * 9) / 5) + 32
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim t As Integer
        If TextBox2.TextLength = 0 Then
            MsgBox("Mete Algo .... capullin")
        Else
            Try
                t = Convert.ToInt16(TextBox2.Text)
            Catch ex As Exception
                MsgBox("Mete numeros zopenco")
            End Try
        End If
        If t <> 0 Then
            TextBox1.Text = ((t - 32) * 5) / 9
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Do While TextBox3.TextLength = 0
            TextBox3.Text = InputBox(Label5.Text, "Para meter el")
        Loop

        Dim a As Integer
        Do While TextBox4.TextLength = 0
            Try
                a = Convert.ToInt16(InputBox(Label6.Text, "Para meter el"))
            Catch ex As Exception
                MsgBox("Berzas .... mete un numero")
            End Try
            If a <> 0 And a > 0 Then
                TextBox4.Text = a
            End If
        Loop
    End Sub

    Private Sub CopiarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopiarToolStripMenuItem.Click
        If TextBox5.SelectionLength > 0 Then
            Clipboard.SetText(TextBox5.SelectedText)
        End If
    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click
        ' Modal
        Form2.ShowDialog()
        ' NO Modal
        Form2.Show()

    End Sub

    Private Sub PegarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PegarToolStripMenuItem.Click
        TextBox6.Text = TextBox6.Text + Clipboard.GetText
    End Sub

    Private Sub CortarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CortarToolStripMenuItem.Click
        If TextBox5.SelectionLength > 0 Then
            Clipboard.SetText(TextBox5.SelectedText)
            TextBox5.SelectedText = ""
        End If
    End Sub

    Private Sub LimpiarPortapapelesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarPortapapelesToolStripMenuItem.Click
        Clipboard.Clear()

    End Sub

    Private Sub CourierNewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourierNewToolStripMenuItem.Click
        RichTextBox1.Font = New Font("Courier New", RichTextBox1.Font.Size)
        CourierNewToolStripMenuItem.Checked = True
        ArialToolStripMenuItem.Checked = False
        SymbolToolStripMenuItem.Checked = False
    End Sub

    Private Sub ArialToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ArialToolStripMenuItem.Click
        RichTextBox1.Font = New Font("Arial", RichTextBox1.Font.Size)
        CourierNewToolStripMenuItem.Checked = False
        ArialToolStripMenuItem.Checked = True
        SymbolToolStripMenuItem.Checked = False
    End Sub

    Private Sub SymbolToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SymbolToolStripMenuItem.Click
        RichTextBox1.Font = New Font("Symbol", RichTextBox1.Font.Size)
        CourierNewToolStripMenuItem.Checked = False
        ArialToolStripMenuItem.Checked = False
        SymbolToolStripMenuItem.Checked = True
    End Sub

    Private Sub Tamano_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click, ToolStripMenuItem3.Click, ToolStripMenuItem4.Click
        If sender.Name = "ToolStripMenuItem2" Then
            RichTextBox1.Font = New Font(RichTextBox1.Font.Name, 10)
            ToolStripMenuItem2.Checked = True
            ToolStripMenuItem3.Checked = False
            ToolStripMenuItem4.Checked = False
        ElseIf sender.Name = "ToolStripMenuItem3" Then
            RichTextBox1.Font = New Font(RichTextBox1.Font.Name, 12)
            ToolStripMenuItem2.Checked = False
            ToolStripMenuItem3.Checked = True
            ToolStripMenuItem4.Checked = False
        Else
            RichTextBox1.Font = New Font(RichTextBox1.Font.Name, 24)
            ToolStripMenuItem2.Checked = False
            ToolStripMenuItem3.Checked = False
            ToolStripMenuItem4.Checked = True


        End If
    End Sub

    Private Sub Fondo_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem.Click, VerdeToolStripMenuItem.Click, AzulToolStripMenuItem.Click
        If sender.Name = "BlancoToolStripMenuItem" Then
            RichTextBox1.BackColor = Color.White
        ElseIf sender.Name = "VerdeToolStripMenuItem" Then
            RichTextBox1.BackColor = Color.Green
        Else
            RichTextBox1.BackColor = Color.Blue
        End If


    End Sub

    Private Sub NegroToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NegroToolStripMenuItem.Click
        RichTextBox1.ForeColor = Color.Red
    End Sub

    Private Sub MayusculasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MayusculasToolStripMenuItem.Click
        RichTextBox1.Text = RichTextBox1.Text.ToUpper
    End Sub

    Private Sub MinusculasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MinusculasToolStripMenuItem.Click
        RichTextBox1.Text = RichTextBox1.Text.ToLower
    End Sub

    Private Sub iniciar_raton()
        TextBox7.Enabled = False
        TextBox7.ReadOnly = False
        TextBox7.Text = ""
        TextBox8.Enabled = False
        TextBox8.ReadOnly = False
        TextBox8.Text = ""
        TextBox9.Enabled = False
        TextBox9.ReadOnly = False
        TextBox9.Text = ""
        Button6.Text = "G.B."

        Button6.ForeColor = Color.Blue
        Button6.BackColor = Color.Cyan
        Button5.Text = "Spain"
        Button5.ForeColor = Color.Blue
        Button5.BackColor = Color.Cyan
        Button7.Text = "Campeon"
        Button7.Enabled = False
        Button7.BackColor = Color.Cyan

    End Sub

    Private Sub activar_campeon()
        If Button5.Enabled = False And
           Button6.Enabled = False Then
            Button7.Enabled = True
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Button5.Enabled = False
        TextBox7.Text = "100"
        TextBox7.ReadOnly = True
        TextBox7.Enabled = True
        activar_campeon()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Button6.Enabled = False
        TextBox8.Text = "160"
        TextBox8.ReadOnly = True
        TextBox8.Enabled = True
        activar_campeon()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Button7.Enabled = False
        TextBox9.Text = "Win Spain"
        TextBox9.ReadOnly = True
        TextBox9.Enabled = True
    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.MouseLeave, TextBox9.MouseEnter, TextBox9.MouseMove
        MsgBox("iniciando en juego")
        iniciar_raton()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        ' Cualquiera de ellas
        TextBox10.Clear()
        TextBox10.Text = ""
        TextBox10.Text = Nothing

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        RichTextBox2.AppendText(TextBox10.Text)
        RichTextBox2.Text = RichTextBox2.Text & " " & TextBox10.Text
        control_caracteres()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        RichTextBox2.Clear()
        control_caracteres()
    End Sub

    Private Sub control_caracteres()
        Label13.Text = RichTextBox2.TextLength
        Label15.Text = RichTextBox2.SelectionLength
    End Sub

    Private Sub RichTextBox2_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox2.MouseLeave
        control_caracteres()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        RichTextBox2.Focus()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        RichTextBox2.SelectAll()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        For index = 0 To Controls.Count - 1
            If (TypeOf Controls(index) Is Label) Then
                Controls(index).ForeColor = Color.Red
            End If

        Next
    End Sub


    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        For index = 0 To Controls.Count - 1
            If (TypeOf Controls(index) Is TextBox Or
                TypeOf Controls(index) Is RichTextBox) Then
                Controls(index).BackColor = Color.Green
            End If

        Next
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        For index = 0 To Controls.Count - 1
            If (TypeOf Controls(index) Is Button) Then
                Controls(index).BackColor = Color.Blue
            End If

        Next
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Controls.Remove(TextBox11)

        Dim etNueva As Label = Nothing           'la declaro  
        etNueva = New Label()                    'la creo 
        etNueva.Name = "etNueva"                 'le doy un nombre
        etNueva.Text = "Etiqueta Nueva...."      'le doy las propiedades 
        etNueva.Location = New Point(400, 250)    'le doy las propiedades 

        Controls.Add(etNueva)
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        TextBox12.BackColor = Color.Yellow
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        TextBox12.BackColor = Color.GreenYellow
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        TextBox12.BackColor = Color.Red
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        TextBox12.Font = New Font("Tahoma", TextBox12.Font.Size)
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        TextBox12.Font = New Font("Garamond", TextBox12.Font.Size)
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        TextBox12.Font = New Font("Magneto", TextBox12.Font.Size)
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        RichTextBox3.Clear()
    End Sub



    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        If TextBox13.TextLength > 0 Then
            ListBox1.Items.Add(TextBox13.Text)
            TextBox13.Clear()

        End If

    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click

        ListBox1.ClearSelected()

        If TextBox13.TextLength > 0 And (ListBox1.SelectionMode <> SelectionMode.None) Then
            Dim i As Integer = ListBox1.FindString(TextBox13.Text)

            If i = ListBox1.NoMatches Then
                MessageBox.Show("No existe el valor")
            Else
                ListBox1.SetSelected(i, True)
            End If

        End If
    End Sub

    Private Sub RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton7.CheckedChanged
        ListBox1.SelectionMode = SelectionMode.One
    End Sub
    Private Sub RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton8.CheckedChanged
        ListBox1.SelectionMode = SelectionMode.MultiSimple
    End Sub

    Private Sub RadioButton9_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton9.CheckedChanged
        ListBox1.SelectionMode = SelectionMode.MultiExtended
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If ListBox1.Sorted = False Then
            ListBox1.Sorted = True
        Else
            ListBox1.Sorted = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = False Then
            ListBox1.MultiColumn = False
        Else
            ListBox1.MultiColumn = True
        End If
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        For index = 0 To ListBox1.SelectedItems.Count - 1
            RichTextBox3.Text = RichTextBox3.Text & ListBox1.SelectedItems(index) & vbCrLf
            ' la que mas asco nos de
            RichTextBox3.AppendText(ListBox1.SelectedItems(index) & vbCrLf)

        Next
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        If ListBox1.Items.Count > 5 Then
            ' If (ListBox1.SelectionMode <> SelectionMode.None) Then
            ListBox1.SelectionMode = SelectionMode.MultiSimple
            ListBox1.SetSelected(1, True)
            ListBox1.SetSelected(2, True)
            ListBox1.SetSelected(4, True)
            'End If
        Else
            MessageBox.Show("Faltan valores")
        End If

    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        ComboBox1.Items.Add("NEGRO")
        ComboBox1.Items.AddRange(New String() {"AZUL", "VERDE", "AMARILLO", "ROJO", "BLANCO", "MARRÓN", "GRANATE"})
        ComboBox2.Items.AddRange(New String() {"AZUL", "VERDE", "AMARILLO"})
        ComboBox3.Items.AddRange(New String() {"AZUL", "VERDE", "AMARILLO", "ROJO"})
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        If TextBox14.TextLength > 0 Then
            Dim p As Integer = ComboBox1.FindString(TextBox14.Text)
            If p = -1 Then
                ComboBox1.Items.Add(TextBox14.Text)
            End If
        End If
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        If TextBox14.TextLength > 0 Then
            Dim p As Integer = ComboBox1.FindString(TextBox14.Text)
            If p = -1 Then
                MessageBox.Show("No existe el valor")
            Else
                ComboBox1.Items.Remove(TextBox14.Text)
                'ComboBox1.Items.RemoveAt(0)
                'Eliminar el elemento que está seleccionado
                'ComboBox1.Items.Remove(ComboBox1.SelectedItem)
            End If
        End If
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        If TextBox14.TextLength > 0 Then
            Dim p As Integer = ComboBox1.FindString(TextBox14.Text)
            If p = -1 Then
                MessageBox.Show("No existe el valor")
            Else
                'ComboBox1.SelectedItem(p)
                'ComboBox1.Items.RemoveAt(0)
                'Eliminar el elemento que está seleccionado
                'ComboBox1.Items.Remove(ComboBox1.SelectedItem)
            End If
        End If
    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        Dim l As String = "paso a pepe"
        lanzar_funcion(l)
        MsgBox(l)
        lanzar_funcion_r(l)
        MsgBox(l)
    End Sub

    Private Sub lanzar_funcion(ByVal l As String)
        MsgBox(l)
        l = "de vuelta"
    End Sub

    Private Sub lanzar_funcion_r(ByRef l As String)
        MsgBox(l)

        For index = 1 To 5
            MsgBox(index)
        Next
        MsgBox("Ahora un Array para subir la moral")
        Dim matriz(5) As String
        For index = 0 To matriz.GetUpperBound(0)
            matriz(index) = InputBox("Dame algo")
        Next
        MsgBox("Ahora un Array para subir la moral. Lo muestro")
        For Each l In matriz
            MsgBox(l)
        Next
        l = "de vuelta R"
    End Sub

    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        Examen()
    End Sub

    Sub problema2()

        Dim persona() As String
        Dim salario() As Double

        meterDatos(persona, salario)
        sacarDatos(persona, salario)

    End Sub


    Sub meterDatos(ByRef persona() As String, ByRef salario() As Double)

        Dim c As Integer = 0
        Dim s As String

        Do
            ReDim Preserve persona(c)
            ReDim Preserve salario(c)

            Console.WriteLine("Nombre Persona")
            persona(c) = Console.ReadLine()

            Console.WriteLine("Salario")
            salario(c) = Convert.ToDouble(Console.ReadLine())

            Console.WriteLine("Seguir (S)")
            s = Console.ReadLine()

            c = c + 1
        Loop While s = "S"

    End Sub

    Sub sacarDatos(ByVal persona() As String, ByVal salario() As Double)

        Dim mas As Integer
        Dim menos As Integer
        Dim max As Double
        Dim min As Double

        For index = 0 To salario.GetUpperBound(0)
            If index = 0 Then
                min = salario(index)
                max = salario(index)
                mas = index
                min = index
            End If
            If salario(index) > max Then
                max = salario(index)
                mas = index
            End If
            If salario(index) < min Then
                min = salario(index)
                menos = index
            End If
        Next

        Console.WriteLine("Maximo Salario")
        Console.WriteLine("- Persona: " & persona(mas))
        Console.WriteLine("- salario: " & salario(mas))

        Console.WriteLine("Minimo Salario")
        Console.WriteLine("- Persona: " & persona(menos))
        Console.WriteLine("- salario: " & salario(menos))

        Console.ReadKey()

    End Sub


    Sub problema1()
        Dim a As Integer
        Dim b As Integer
        Dim suma As Integer

        entradaDatos(a, b)
        sumarMultiplosDeCinco(a, b, suma)
        visualizarSuma(suma)

    End Sub

    Sub entradaDatos(ByRef a, ByRef b)

        Dim c As Integer

        Do
            Try
                Console.WriteLine("Dame el valor 1")
                a = Convert.ToInt32(Console.ReadLine())
                Console.WriteLine("Dame el valor 2")
                b = Convert.ToInt32(Console.ReadLine())
            Catch ex As Exception
                mal()
            End Try

        Loop While a < 0 Or b < 0

        If a > b Then
            c = a
            a = b
            b = c
        End If

    End Sub

    Sub mal()
        Console.WriteLine("numero erroneo")
    End Sub

    Sub sumarMultiplosDeCinco(ByVal a, ByVal b, ByRef suma)
        suma = 0
        For index = a To b
            If index Mod 5 = 0 Then
                suma = suma + index
            End If
        Next

    End Sub

    Sub visualizarSuma(ByVal suma)
        Console.WriteLine("La suma es : " & suma)
        Console.ReadKey()
    End Sub


    Sub Examen()

        Dim opcion As Integer
        MsgBox("Entro")
        Do
            Console.WriteLine("1. Ejecutar Problema 1")
            Console.WriteLine("2. Ejecutar Problema 2")
            Console.WriteLine("3. Salir")
            opcion = Convert.ToInt32(Console.ReadLine())

            Select Case opcion
                Case 1
                    problema1()
                Case 2
                    problema2()
            End Select

        Loop While opcion <> 3


    End Sub
End Class




