﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Esta es la ventana de Acerca de"
        Label1.Text = " Salir."


    End Sub

    Private Sub Raton(sender As Object, e As MouseEventArgs) Handles Me.MouseMove, Label1.Click
        Me.Text = "raton en x: " & e.X & " y: " & e.Y
    End Sub

    Private Sub Salir(sender As Object, e As EventArgs) Handles Label1.MouseEnter
        Me.Close()
    End Sub

    Private Sub Button1_MouseEnter(sender As Object, e As EventArgs) Handles Button1.MouseEnter

        Button2.BackColor = Color.Blue

        AddHandler Button2.Click, AddressOf cambiar_nombre
        AddHandler Button2.MouseEnter, AddressOf cambiar_nombre

    End Sub

    Sub cambiar_nombre()
        Me.Text = "Cambio el nombre del formulario"
    End Sub


End Class