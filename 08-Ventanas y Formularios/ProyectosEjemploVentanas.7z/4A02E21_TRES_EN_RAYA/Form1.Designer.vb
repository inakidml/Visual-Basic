﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.etTitulo = New System.Windows.Forms.Label()
        Me.b11 = New System.Windows.Forms.Button()
        Me.b12 = New System.Windows.Forms.Button()
        Me.b13 = New System.Windows.Forms.Button()
        Me.b21 = New System.Windows.Forms.Button()
        Me.b22 = New System.Windows.Forms.Button()
        Me.b23 = New System.Windows.Forms.Button()
        Me.b31 = New System.Windows.Forms.Button()
        Me.b32 = New System.Windows.Forms.Button()
        Me.b33 = New System.Windows.Forms.Button()
        Me.bJugador0 = New System.Windows.Forms.Button()
        Me.bJugador1 = New System.Windows.Forms.Button()
        Me.bSalir = New System.Windows.Forms.Button()
        Me.bIniciar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'etTitulo
        '
        Me.etTitulo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etTitulo.AutoSize = True
        Me.etTitulo.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etTitulo.Location = New System.Drawing.Point(72, 37)
        Me.etTitulo.Name = "etTitulo"
        Me.etTitulo.Size = New System.Drawing.Size(215, 25)
        Me.etTitulo.TabIndex = 0
        Me.etTitulo.Text = "     TRES EN RAYA"
        Me.etTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'b11
        '
        Me.b11.Location = New System.Drawing.Point(56, 152)
        Me.b11.Name = "b11"
        Me.b11.Size = New System.Drawing.Size(75, 64)
        Me.b11.TabIndex = 1
        '
        'b12
        '
        Me.b12.Location = New System.Drawing.Point(144, 152)
        Me.b12.Name = "b12"
        Me.b12.Size = New System.Drawing.Size(75, 64)
        Me.b12.TabIndex = 2
        '
        'b13
        '
        Me.b13.Location = New System.Drawing.Point(232, 152)
        Me.b13.Name = "b13"
        Me.b13.Size = New System.Drawing.Size(75, 64)
        Me.b13.TabIndex = 3
        '
        'b21
        '
        Me.b21.Location = New System.Drawing.Point(56, 224)
        Me.b21.Name = "b21"
        Me.b21.Size = New System.Drawing.Size(75, 64)
        Me.b21.TabIndex = 4
        '
        'b22
        '
        Me.b22.Location = New System.Drawing.Point(144, 224)
        Me.b22.Name = "b22"
        Me.b22.Size = New System.Drawing.Size(75, 64)
        Me.b22.TabIndex = 5
        '
        'b23
        '
        Me.b23.Location = New System.Drawing.Point(232, 224)
        Me.b23.Name = "b23"
        Me.b23.Size = New System.Drawing.Size(75, 64)
        Me.b23.TabIndex = 6
        '
        'b31
        '
        Me.b31.Location = New System.Drawing.Point(56, 296)
        Me.b31.Name = "b31"
        Me.b31.Size = New System.Drawing.Size(75, 64)
        Me.b31.TabIndex = 7
        '
        'b32
        '
        Me.b32.Location = New System.Drawing.Point(144, 296)
        Me.b32.Name = "b32"
        Me.b32.Size = New System.Drawing.Size(75, 64)
        Me.b32.TabIndex = 8
        '
        'b33
        '
        Me.b33.Location = New System.Drawing.Point(232, 296)
        Me.b33.Name = "b33"
        Me.b33.Size = New System.Drawing.Size(75, 64)
        Me.b33.TabIndex = 9
        '
        'bJugador0
        '
        Me.bJugador0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.bJugador0.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bJugador0.ForeColor = System.Drawing.Color.White
        Me.bJugador0.Location = New System.Drawing.Point(56, 105)
        Me.bJugador0.Name = "bJugador0"
        Me.bJugador0.Size = New System.Drawing.Size(87, 32)
        Me.bJugador0.TabIndex = 10
        Me.bJugador0.Text = "Jugador 1"
        Me.bJugador0.UseVisualStyleBackColor = False
        '
        'bJugador1
        '
        Me.bJugador1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bJugador1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bJugador1.ForeColor = System.Drawing.Color.White
        Me.bJugador1.Location = New System.Drawing.Point(216, 105)
        Me.bJugador1.Name = "bJugador1"
        Me.bJugador1.Size = New System.Drawing.Size(91, 32)
        Me.bJugador1.TabIndex = 11
        Me.bJugador1.Text = "Jugador 2"
        Me.bJugador1.UseVisualStyleBackColor = False
        '
        'bSalir
        '
        Me.bSalir.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bSalir.Location = New System.Drawing.Point(48, 384)
        Me.bSalir.Name = "bSalir"
        Me.bSalir.Size = New System.Drawing.Size(272, 40)
        Me.bSalir.TabIndex = 12
        Me.bSalir.Text = "Salir"
        '
        'bIniciar
        '
        Me.bIniciar.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bIniciar.Location = New System.Drawing.Point(56, 82)
        Me.bIniciar.Name = "bIniciar"
        Me.bIniciar.Size = New System.Drawing.Size(252, 31)
        Me.bIniciar.TabIndex = 13
        Me.bIniciar.Text = "Iniciar Partida"
        Me.bIniciar.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(376, 443)
        Me.ControlBox = False
        Me.Controls.Add(Me.bIniciar)
        Me.Controls.Add(Me.bSalir)
        Me.Controls.Add(Me.bJugador1)
        Me.Controls.Add(Me.bJugador0)
        Me.Controls.Add(Me.b33)
        Me.Controls.Add(Me.b32)
        Me.Controls.Add(Me.b31)
        Me.Controls.Add(Me.b23)
        Me.Controls.Add(Me.b22)
        Me.Controls.Add(Me.b21)
        Me.Controls.Add(Me.b13)
        Me.Controls.Add(Me.b12)
        Me.Controls.Add(Me.b11)
        Me.Controls.Add(Me.etTitulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "4A02E20_BUTTON"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents etTitulo As System.Windows.Forms.Label
    Friend WithEvents b11 As System.Windows.Forms.Button
    Friend WithEvents b12 As System.Windows.Forms.Button
    Friend WithEvents b13 As System.Windows.Forms.Button
    Friend WithEvents b21 As System.Windows.Forms.Button
    Friend WithEvents b22 As System.Windows.Forms.Button
    Friend WithEvents b23 As System.Windows.Forms.Button
    Friend WithEvents b31 As System.Windows.Forms.Button
    Friend WithEvents b32 As System.Windows.Forms.Button
    Friend WithEvents b33 As System.Windows.Forms.Button
    Friend WithEvents bJugador0 As System.Windows.Forms.Button
    Friend WithEvents bJugador1 As System.Windows.Forms.Button
    Friend WithEvents bSalir As System.Windows.Forms.Button
    Friend WithEvents bIniciar As System.Windows.Forms.Button
End Class
