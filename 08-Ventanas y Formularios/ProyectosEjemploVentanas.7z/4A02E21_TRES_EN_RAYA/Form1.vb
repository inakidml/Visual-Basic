﻿
Public Class Form1
    'Declaracion de variables
    Dim tabla(,) As Integer = ({{5, 5, 5, 5, 0}, {5, 5, 5, 5, 0}, {5, 5, 5, 5, 0}, {0, 0, 0, 0, 0}})

    Dim boton As Button
    Dim Random As New Random()
    Dim jugador As Integer = Random.Next(0, 2) 'toma valores aleatorios entre 0 y 1 ambos inclusive
    Dim ganador As String = " "

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Text = "TRES EN RAYA"
        'La primera vez haremos
        If jugador = 0 Then
            bJugador0.Visible = True
            bJugador1.Visible = False
            'jugador_1()
        Else
            bJugador0.Visible = False
            bJugador1.Visible = True
            'jugador_0()
        End If
        bIniciar.Visible = False
    End Sub

    Private Sub detecta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                   Handles b11.Click, b12.Click, b33.Click, b32.Click, b31.Click, b23.Click, b22.Click, b21.Click, b13.Click
        boton = CType(sender, Button)
        marcarCasilla(boton)
    End Sub

    Private Sub marcarCasilla(ByVal boton As Button)
        Dim nombreBoton As String = boton.Name

        'Restando 1 a la fila del botón obtenemos la posición en la Tabla donde marcamos el click
        Dim f As Integer = CInt(nombreBoton.Substring(1, 1)) - 1
        Dim c As Integer = CInt(nombreBoton.Substring(2, 1))

        If (bJugador0.Visible = True) Then
            tabla(f, c) = 0
            boton.BackColor = Color.Red
            jugador_0()
        Else
            tabla(f, c) = 1
            boton.BackColor = Color.Blue
            jugador_1()
        End If
        boton.Enabled = False

        ganarPartida()
    End Sub

    Private Sub jugador_0()
        bJugador0.Visible = False
        bJugador1.Visible = True
        'jugador = 1
    End Sub

    Private Sub jugador_1()
        bJugador1.Visible = False
        bJugador0.Visible = True
        'jugador = 0
    End Sub

    Private Sub ganarPartida()
        'inicializar fila y columna de rdos
        For x = 0 To 3
            tabla(3, x) = 0
            tabla(x, 4) = 0
        Next

        'inicializo casillas de control de diagonales
        tabla(3, 0) = 0 : tabla(3, 4) = 0

        'calculo la suma de filas y columnas desde (0,1)...(2,3)
        For f = 0 To 2
            For c = 1 To 3
                tabla(f, 4) += tabla(f, c)  'suma de la fila
                tabla(3, c) += tabla(f, c)  'suma de la columna
            Next
        Next

        'calculo la suma de las diagonales
        tabla(3, 4) = tabla(0, 1) + tabla(1, 2) + tabla(2, 3) 'rdo diagonal_1
        tabla(3, 0) = tabla(0, 3) + tabla(1, 2) + tabla(2, 1) 'rdo diagonal_2

        'controlo fin partida a través de las sumas obtenidas
        Dim controlEmpate As Boolean = True
        If (tabla(3, 0) = 0 Or tabla(3, 4) = 0) Then 'diagonal_1
            ganador = "Enhorabuena Rojo"     'gana jugador_0
            controlEmpate = False
            bloquearTablero()
        ElseIf (tabla(3, 4) = 3 Or tabla(3, 0) = 3) Then 'diagonal_2
            ganador = "Enhorabuena Azul"     'gana jugador_1
            controlEmpate = False
            bloquearTablero()
        Else
            For x = 0 To 3
                If (tabla(3, x) = 0 Or tabla(x, 4) = 0) Then 'fila o culumna
                    ganador = "Enhorabuena Rojo"     'gana jugador_0
                    controlEmpate = False
                    bloquearTablero()
                    Exit For
                ElseIf (tabla(3, x) = 3 Or tabla(x, 4) = 3) Then 'fila o culumna
                    ganador = "Enhorabuena Azul"    'gana jugador_1
                    controlEmpate = False
                    bloquearTablero()
                    Exit For
                End If
            Next
        End If

        'controlo que estamos en Tablas, si en las casillas no hay ningún 5 
        'Dim cadena As String = ""
        'For f = 0 To 2
        '    For c = 1 To 3
        '        cadena &= tabla(f, c) & " "
        '    Next
        '    cadena &= vbCrLf
        'Next
        'MsgBox(cadena)

        'Será empate si no queda ningún 5 en la tabla, por modificarse con 0 ó 1
        If (controlEmpate = True) Then
            Dim existen5 As Boolean = False
            For f = 0 To 2
                For c = 1 To 3
                    If tabla(f, c) = 5 Then
                        existen5 = True
                        Exit For
                    End If
                Next
            Next
            If existen5 = False Then
                ganador = "Estamos en Tablas"
                bloquearTablero()
            End If
        End If




        'If ((b11.BackColor = Color.Red And b12.BackColor = Color.Red And b13.BackColor = Color.Red) _
        '    Or (b21.BackColor = Color.Red And b22.BackColor = Color.Red And b23.BackColor = Color.Red) _
        '    Or (b31.BackColor = Color.Red And b32.BackColor = Color.Red And b33.BackColor = Color.Red) _
        '    Or (b11.BackColor = Color.Red And b21.BackColor = Color.Red And b31.BackColor = Color.Red) _
        '    Or (b12.BackColor = Color.Red And b22.BackColor = Color.Red And b32.BackColor = Color.Red) _
        '    Or (b13.BackColor = Color.Red And b23.BackColor = Color.Red And b33.BackColor = Color.Red) _
        '    Or (b11.BackColor = Color.Red And b22.BackColor = Color.Red And b33.BackColor = Color.Red) _
        '    Or (b13.BackColor = Color.Red And b22.BackColor = Color.Red And b31.BackColor = Color.Red)) Then
        '    MsgBox("Enhorabuena Rojo")
        '    bloquearTablero()
        'ElseIf ((b11.BackColor = Color.Blue And b12.BackColor = Color.Blue And b13.BackColor = Color.Blue) _
        '    Or (b21.BackColor = Color.Blue And b22.BackColor = Color.Blue And b23.BackColor = Color.Blue) _
        '    Or (b31.BackColor = Color.Blue And b32.BackColor = Color.Blue And b33.BackColor = Color.Blue) _
        '    Or (b11.BackColor = Color.Blue And b21.BackColor = Color.Blue And b31.BackColor = Color.Blue) _
        '    Or (b12.BackColor = Color.Blue And b22.BackColor = Color.Blue And b32.BackColor = Color.Blue) _
        '    Or (b13.BackColor = Color.Blue And b23.BackColor = Color.Blue And b33.BackColor = Color.Blue) _
        '    Or (b11.BackColor = Color.Blue And b22.BackColor = Color.Blue And b33.BackColor = Color.Blue) _
        '    Or (b13.BackColor = Color.Blue And b22.BackColor = Color.Blue And b31.BackColor = Color.Blue)) Then
        '    MsgBox("Enhorabuena Azul")
        '    bloquearTablero()
        'ElseIf ((b11.BackColor <> SystemColors.Control And b12.BackColor <> SystemColors.Control And b13.BackColor <> SystemColors.Control) _
        '        And (b21.BackColor <> SystemColors.Control And b22.BackColor <> SystemColors.Control And b23.BackColor <> SystemColors.Control) _
        '        And (b31.BackColor <> SystemColors.Control And b32.BackColor <> SystemColors.Control And b33.BackColor <> SystemColors.Control)) Then
        '    MsgBox("Estamos en Tablas...")
        '    bloquearTablero()
        'End If

    End Sub

    Private Sub bloquearTablero()
        etTitulo.Text = ganador
        etTitulo.BackColor = Color.Aquamarine

        'inhabilito botones
        b11.Enabled = False
        b12.Enabled = False
        b13.Enabled = False
        b21.Enabled = False
        b22.Enabled = False
        b23.Enabled = False
        b31.Enabled = False
        b32.Enabled = False
        b33.Enabled = False

        'oculto jugadores
        bJugador0.Visible = False
        bJugador1.Visible = False

        'visualizo el boton de Iniciar partida o Salir
        bSalir.Focus()     'establece el foco en el boton salir
        bIniciar.Visible = True
    End Sub

    Private Sub bIniciar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bIniciar.Click
        'restauro los valores en la tabla
        tabla = ({{5, 5, 5, 5, 0}, {5, 5, 5, 5, 0}, {5, 5, 5, 5, 0}, {0, 0, 0, 0, 0}})
        jugador = Random.Next(0, 2) 'toma valores aleatorios entre 0 y 1 ambos inclusive

        'doy paso al primer jugador
        If jugador = 0 Then
            bJugador0.Visible = True
            bJugador1.Visible = False
        Else
            bJugador0.Visible = False
            bJugador1.Visible = True
        End If

        'habilitar tablero
        etTitulo.ResetBackColor()
        etTitulo.Text = "TRES EN RAYA"

        'habilito botones
        b11.Enabled = True
        b12.Enabled = True
        b13.Enabled = True
        b21.Enabled = True
        b22.Enabled = True
        b23.Enabled = True
        b31.Enabled = True
        b32.Enabled = True
        b33.Enabled = True

        'restauro color en botones
        b11.ResetBackColor()
        b12.ResetBackColor()
        b13.ResetBackColor()
        b21.ResetBackColor()
        b22.ResetBackColor()
        b23.ResetBackColor()
        b31.ResetBackColor()
        b32.ResetBackColor()
        b33.ResetBackColor()

        'oculto el boton de Iniciar partida
        b22.Focus() 'establece el foco en el boton central
        bIniciar.Visible = False
    End Sub

    Private Sub bSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bSalir.Click
        End
    End Sub



    'Tabla ejemplo para trabajar. En la columna 0 sólo guardo la suma de UNA diagonal
    'la columna 4, para guardar la suma de cada fila y la suma de la otra diagonal
    'la fila 3 guardar la suma de cada columna y la suma de las dos diagonales
    'creo una matriz de 5x4 y utilizo para marcar 3x3 desde las filas 0..2 y columnas 1..3 
    'las diagonales a sumar van desde T(0,1)<->T(2,3) / T(0,3)<->T(2,1) 
    'T. inicializada a 5 - Modifico al clickear - Si pulsa Rojo modifico a 0, si Azul a 1
    ' Sumo filas, columnas y diagonales y guardo rdo en columna 4 y en fila 3
    'Si suma=0 gana Rojo, si suma=3 gana Azul, se comprueba suma de filas columnas y diagonales  
    '0 5 5 5 f               5 0 0 0 0                     5 1 0 0 1
    '0 5 5 5 f               5 1 0 1 2                     5 0 1 1 2
    '0 5 5 5 f               5 1 0 1 2                     5 1 0 1 2
    'D c c c D               1 2 0 2 2                     2 2 1 2 3

    'Posiciones Tablas
    '     4x5	        <->   Nombres de los botones
    '00 01 02 03 04                11 12 13
    '10 11 12 13 14                21 22 23
    '20 21 22 23 24                31 32 33
    '30 31 32 33 34
    'Restando 1 a la fila del botón obtenemos la posición en la Tabla donde marcamos el click

End Class
