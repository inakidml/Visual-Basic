﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FicheroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EdicionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CortarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopiarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PegarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpcionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FuenteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourierNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VArielToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SymbolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TamañoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FondoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlancoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NegroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 27)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(789, 466)
        Me.TextBox1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FicheroToolStripMenuItem, Me.EdicionToolStripMenuItem, Me.OpcionesToolStripMenuItem, Me.AyudaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(813, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FicheroToolStripMenuItem
        '
        Me.FicheroToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalirToolStripMenuItem})
        Me.FicheroToolStripMenuItem.Name = "FicheroToolStripMenuItem"
        Me.FicheroToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.FicheroToolStripMenuItem.Text = "Fichero"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(96, 22)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'EdicionToolStripMenuItem
        '
        Me.EdicionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CortarToolStripMenuItem, Me.CopiarToolStripMenuItem, Me.PegarToolStripMenuItem})
        Me.EdicionToolStripMenuItem.Name = "EdicionToolStripMenuItem"
        Me.EdicionToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.EdicionToolStripMenuItem.Text = "Edicion"
        '
        'CortarToolStripMenuItem
        '
        Me.CortarToolStripMenuItem.Name = "CortarToolStripMenuItem"
        Me.CortarToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.CortarToolStripMenuItem.Text = "Cortar"
        '
        'CopiarToolStripMenuItem
        '
        Me.CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem"
        Me.CopiarToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.CopiarToolStripMenuItem.Text = "Copiar"
        '
        'PegarToolStripMenuItem
        '
        Me.PegarToolStripMenuItem.Name = "PegarToolStripMenuItem"
        Me.PegarToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.PegarToolStripMenuItem.Text = "Pegar"
        '
        'OpcionesToolStripMenuItem
        '
        Me.OpcionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TextoToolStripMenuItem})
        Me.OpcionesToolStripMenuItem.Name = "OpcionesToolStripMenuItem"
        Me.OpcionesToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.OpcionesToolStripMenuItem.Text = "Opciones"
        '
        'TextoToolStripMenuItem
        '
        Me.TextoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FuenteToolStripMenuItem, Me.TamañoToolStripMenuItem, Me.ColoresToolStripMenuItem})
        Me.TextoToolStripMenuItem.Name = "TextoToolStripMenuItem"
        Me.TextoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TextoToolStripMenuItem.Text = "Texto"
        '
        'FuenteToolStripMenuItem
        '
        Me.FuenteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourierNewToolStripMenuItem, Me.VArielToolStripMenuItem, Me.SymbolToolStripMenuItem})
        Me.FuenteToolStripMenuItem.Name = "FuenteToolStripMenuItem"
        Me.FuenteToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FuenteToolStripMenuItem.Text = "Fuente"
        '
        'CourierNewToolStripMenuItem
        '
        Me.CourierNewToolStripMenuItem.Name = "CourierNewToolStripMenuItem"
        Me.CourierNewToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CourierNewToolStripMenuItem.Text = "Courier New"
        '
        'VArielToolStripMenuItem
        '
        Me.VArielToolStripMenuItem.Name = "VArielToolStripMenuItem"
        Me.VArielToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VArielToolStripMenuItem.Text = "V Ariel"
        '
        'SymbolToolStripMenuItem
        '
        Me.SymbolToolStripMenuItem.Name = "SymbolToolStripMenuItem"
        Me.SymbolToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SymbolToolStripMenuItem.Text = "Symbol"
        '
        'TamañoToolStripMenuItem
        '
        Me.TamañoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4})
        Me.TamañoToolStripMenuItem.Name = "TamañoToolStripMenuItem"
        Me.TamañoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TamañoToolStripMenuItem.Text = "Tamaño"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(152, 22)
        Me.ToolStripMenuItem2.Text = "10"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(152, 22)
        Me.ToolStripMenuItem3.Text = "20"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(152, 22)
        Me.ToolStripMenuItem4.Text = "30"
        '
        'ColoresToolStripMenuItem
        '
        Me.ColoresToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FondoToolStripMenuItem, Me.TextoToolStripMenuItem1})
        Me.ColoresToolStripMenuItem.Name = "ColoresToolStripMenuItem"
        Me.ColoresToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ColoresToolStripMenuItem.Text = "Colores"
        '
        'AyudaToolStripMenuItem
        '
        Me.AyudaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcercaDeToolStripMenuItem})
        Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.AyudaToolStripMenuItem.Text = "Ayuda"
        '
        'AcercaDeToolStripMenuItem
        '
        Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
        Me.AcercaDeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AcercaDeToolStripMenuItem.Text = "Acerca de..."
        '
        'FondoToolStripMenuItem
        '
        Me.FondoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerdeToolStripMenuItem, Me.BlancoToolStripMenuItem, Me.AzulToolStripMenuItem})
        Me.FondoToolStripMenuItem.Name = "FondoToolStripMenuItem"
        Me.FondoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FondoToolStripMenuItem.Text = "Fondo"
        '
        'VerdeToolStripMenuItem
        '
        Me.VerdeToolStripMenuItem.Name = "VerdeToolStripMenuItem"
        Me.VerdeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VerdeToolStripMenuItem.Text = "Verde"
        '
        'BlancoToolStripMenuItem
        '
        Me.BlancoToolStripMenuItem.Name = "BlancoToolStripMenuItem"
        Me.BlancoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BlancoToolStripMenuItem.Text = "Blanco"
        '
        'AzulToolStripMenuItem
        '
        Me.AzulToolStripMenuItem.Name = "AzulToolStripMenuItem"
        Me.AzulToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AzulToolStripMenuItem.Text = "Azul"
        '
        'TextoToolStripMenuItem1
        '
        Me.TextoToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NegroToolStripMenuItem, Me.VerdeToolStripMenuItem1, Me.AzulToolStripMenuItem1})
        Me.TextoToolStripMenuItem1.Name = "TextoToolStripMenuItem1"
        Me.TextoToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.TextoToolStripMenuItem1.Text = "Texto"
        '
        'NegroToolStripMenuItem
        '
        Me.NegroToolStripMenuItem.Name = "NegroToolStripMenuItem"
        Me.NegroToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.NegroToolStripMenuItem.Text = "Negro"
        '
        'VerdeToolStripMenuItem1
        '
        Me.VerdeToolStripMenuItem1.Name = "VerdeToolStripMenuItem1"
        Me.VerdeToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.VerdeToolStripMenuItem1.Text = "Verde"
        '
        'AzulToolStripMenuItem1
        '
        Me.AzulToolStripMenuItem1.Name = "AzulToolStripMenuItem1"
        Me.AzulToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.AzulToolStripMenuItem1.Text = "Azul"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(813, 505)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Editor de textos"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FicheroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EdicionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CortarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PegarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpcionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FuenteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourierNewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VArielToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SymbolToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TamañoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ColoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FondoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BlancoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents NegroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem1 As ToolStripMenuItem
End Class
