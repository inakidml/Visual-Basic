﻿Public Class Form1
    Dim tamaño As Integer
    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem3.Click
        TextBox1.Font = New Font(TextBox1.Font.Style, 12)

    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub CortarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CortarToolStripMenuItem.Click
        If TextBox1.SelectedText <> Nothing Then
            Clipboard.SetText(TextBox1.SelectedText)
            TextBox1.SelectedText = ""
        End If

    End Sub

    Private Sub CopiarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopiarToolStripMenuItem.Click
        If TextBox1.SelectedText <> Nothing Then
            Clipboard.SetText(TextBox1.SelectedText)
        End If
    End Sub

    Private Sub PegarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PegarToolStripMenuItem.Click
        TextBox1.SelectedText = Clipboard.GetText
    End Sub

    Private Sub CourierNewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourierNewToolStripMenuItem.Click
        TextBox1.Font = New Font("Courier New", TextBox1.Font.Size)
    End Sub

    Private Sub VArielToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VArielToolStripMenuItem.Click
        TextBox1.Font = New Font("Ariel", TextBox1.Font.Size)

    End Sub

    Private Sub SymbolToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SymbolToolStripMenuItem.Click
        TextBox1.Font = New Font("Symbol", TextBox1.Font.Size)

    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        TextBox1.Font = New Font(TextBox1.Font.Style, 10)
    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem4.Click
        TextBox1.Font = New Font(TextBox1.Font.Style, 24)

    End Sub

    Private Sub VerdeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem.Click
        TextBox1.BackColor = Color.Green
    End Sub

    Private Sub BlancoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem.Click
        TextBox1.BackColor = Color.White

    End Sub

    Private Sub AzulToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem.Click
        TextBox1.BackColor = Color.Blue
    End Sub

    Private Sub NegroToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NegroToolStripMenuItem.Click
        TextBox1.ForeColor = Color.Black
    End Sub

    Private Sub VerdeToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem1.Click
        TextBox1.ForeColor = Color.Green

    End Sub

    Private Sub AzulToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem1.Click
        TextBox1.ForeColor = Color.Blue

    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click
        Form2.Show()
    End Sub
End Class
