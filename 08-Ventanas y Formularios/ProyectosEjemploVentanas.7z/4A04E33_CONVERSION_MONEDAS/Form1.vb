﻿Public Class Form1
    Private objTextBox As TextBox = Nothing ' para recoger el nombre del objeto sender, euros o pesetas

    Dim vpesetas As Double
    Dim veuros As Double
    Dim vformato As String = "#,##0.00"

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ctPesetas.Text() = "1,00"
        ctEuros.Text() = "166,38"
    End Sub

    'Private Sub bPesetas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bPesetas.Click
    '    veuros = CDbl(tbEuros.Text())
    '    vpesetas = veuros * 166.386
    '    tbPesetas.Text() = Format(vpesetas, vformato)
    'End Sub

    'Private Sub bEuros_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bEuros.Click
    '    vpesetas = CDbl(tbPesetas.Text())
    '    veuros = vpesetas / 166.386
    '    tbEuros.Text() = Format(veuros, vformato)
    'End Sub

    Private Sub cambioMoneda(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bEuros.Click, bPesetas.Click
        Dim objtexto As Button = CType(sender, Button)

        If (objtexto Is bEuros) Then
            Try
                vpesetas = CDbl(ctPesetas.Text())
                veuros = vpesetas / 166.386
                ctEuros.Text() = Format(veuros, vformato)
                ' ctEuros.Text() = veuros.ToString
            Catch ex As Exception
                MsgBox("Introduce un número valido por favor")

            End Try


        Else
            Try
                veuros = CDbl(ctEuros.Text())
                vpesetas = veuros * 166.386
                ctPesetas.Text() = Format(vpesetas, vformato)
                'ctPesetas.Text() = veuros.ToString
            Catch ex As Exception
                MsgBox("Introduce un número valido por favor")
            End Try

        End If
    End Sub


    Private Sub CajaTexto_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ctPesetas.MouseEnter, ctEuros.MouseEnter

        objTextBox = CType(sender, TextBox) 'para que saber que campo ctPesetas o ctEuros
        objTextBox.Focus()
        objTextBox.SelectAll()  'selecciona todo el texto de la caja
    End Sub

    Private Sub bSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bSalir.Click
        End
    End Sub

End Class
