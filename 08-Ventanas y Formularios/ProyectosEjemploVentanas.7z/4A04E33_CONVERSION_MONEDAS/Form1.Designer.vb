﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.etTitulo = New System.Windows.Forms.Label()
        Me.etPesetas = New System.Windows.Forms.Label()
        Me.etEuros = New System.Windows.Forms.Label()
        Me.ctPesetas = New System.Windows.Forms.TextBox()
        Me.ctEuros = New System.Windows.Forms.TextBox()
        Me.bPesetas = New System.Windows.Forms.Button()
        Me.bEuros = New System.Windows.Forms.Button()
        Me.bSalir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'etTitulo
        '
        Me.etTitulo.AutoSize = True
        Me.etTitulo.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etTitulo.Location = New System.Drawing.Point(53, 20)
        Me.etTitulo.Name = "etTitulo"
        Me.etTitulo.Size = New System.Drawing.Size(295, 38)
        Me.etTitulo.TabIndex = 0
        Me.etTitulo.Text = "EUROCALCULADORA"
        '
        'etPesetas
        '
        Me.etPesetas.AutoSize = True
        Me.etPesetas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etPesetas.Location = New System.Drawing.Point(21, 86)
        Me.etPesetas.Name = "etPesetas"
        Me.etPesetas.Size = New System.Drawing.Size(86, 13)
        Me.etPesetas.TabIndex = 1
        Me.etPesetas.Text = "Importe Pesetas:"
        '
        'etEuros
        '
        Me.etEuros.AutoSize = True
        Me.etEuros.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etEuros.Location = New System.Drawing.Point(21, 117)
        Me.etEuros.Name = "etEuros"
        Me.etEuros.Size = New System.Drawing.Size(75, 13)
        Me.etEuros.TabIndex = 2
        Me.etEuros.Text = "Importe Euros:"
        '
        'ctPesetas
        '
        Me.ctPesetas.Location = New System.Drawing.Point(129, 83)
        Me.ctPesetas.Name = "ctPesetas"
        Me.ctPesetas.Size = New System.Drawing.Size(100, 20)
        Me.ctPesetas.TabIndex = 3
        Me.ctPesetas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ctEuros
        '
        Me.ctEuros.Location = New System.Drawing.Point(129, 114)
        Me.ctEuros.Name = "ctEuros"
        Me.ctEuros.Size = New System.Drawing.Size(100, 20)
        Me.ctEuros.TabIndex = 4
        Me.ctEuros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'bPesetas
        '
        Me.bPesetas.Location = New System.Drawing.Point(259, 112)
        Me.bPesetas.Name = "bPesetas"
        Me.bPesetas.Size = New System.Drawing.Size(75, 23)
        Me.bPesetas.TabIndex = 5
        Me.bPesetas.Text = "Pesetas"
        Me.bPesetas.UseVisualStyleBackColor = True
        '
        'bEuros
        '
        Me.bEuros.Location = New System.Drawing.Point(259, 81)
        Me.bEuros.Name = "bEuros"
        Me.bEuros.Size = New System.Drawing.Size(75, 23)
        Me.bEuros.TabIndex = 6
        Me.bEuros.Text = "Euros"
        Me.bEuros.UseVisualStyleBackColor = True
        '
        'bSalir
        '
        Me.bSalir.Location = New System.Drawing.Point(247, 154)
        Me.bSalir.Name = "bSalir"
        Me.bSalir.Size = New System.Drawing.Size(100, 23)
        Me.bSalir.TabIndex = 7
        Me.bSalir.Text = "Salir"
        Me.bSalir.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 212)
        Me.Controls.Add(Me.bSalir)
        Me.Controls.Add(Me.bEuros)
        Me.Controls.Add(Me.bPesetas)
        Me.Controls.Add(Me.ctEuros)
        Me.Controls.Add(Me.ctPesetas)
        Me.Controls.Add(Me.etEuros)
        Me.Controls.Add(Me.etPesetas)
        Me.Controls.Add(Me.etTitulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents etTitulo As System.Windows.Forms.Label
    Friend WithEvents etPesetas As System.Windows.Forms.Label
    Friend WithEvents etEuros As System.Windows.Forms.Label
    Friend WithEvents ctPesetas As System.Windows.Forms.TextBox
    Friend WithEvents ctEuros As System.Windows.Forms.TextBox
    Friend WithEvents bPesetas As System.Windows.Forms.Button
    Friend WithEvents bEuros As System.Windows.Forms.Button
    Friend WithEvents bSalir As System.Windows.Forms.Button
End Class

