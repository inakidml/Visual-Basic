﻿Public Class Form1

    'Declaracion de variables

    'Creo una tabla de 7x7 Inserto un fila y columna mas para que coincida el nombre del botón con la posicion
    'inicializo a 5 las nulas, a 9 donde están las bombas, a 0 el resto que modificaré a 1 al pulsar el boton

    Dim tablaControl(,) As Integer = {{5, 5, 5, 5, 5, 5, 5}, _
                                      {5, 0, 0, 0, 0, 0, 0}, _
                                      {5, 0, 9, 0, 0, 0, 0}, _
                                      {5, 0, 0, 0, 9, 0, 0}, _
                                      {5, 0, 0, 9, 0, 0, 0}, _
                                      {5, 0, 0, 0, 0, 9, 0}, _
                                      {5, 0, 9, 0, 0, 0, 0}}


    Private Sub form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bSalir.Enabled = False

        ''en Form1.Designer.vb vemos cada control en que posicion de la tabla lo ha guardado
        'Me.Controls(1).BackColor = Color.Aquamarine
        'MsgBox(Me.Controls(1).Name)
        etSalir.Text = " 5 Bombas!"
    End Sub

    Private Sub bSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bSalir.Click
        End
    End Sub



    Private Sub botonBomba_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                     Handles b62.Click, b55.Click, b43.Click, b34.Click, b22.Click
        'botones con -bomba-
        Dim boton As Button = CType(sender, Button)
        boton.BackColor = Color.Red
        boton.Text = "@"
        etSalir.Text = "Game Over"
        bSalir.Enabled = True
    End Sub

    Private Sub boton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                    Handles b46.Click, b41.Click, b36.Click, b26.Click, b16.Click, b15.Click, b14.Click
        'botones sin texto
        Dim boton As Button = CType(sender, Button)
        boton.BackColor = Color.White
        boton.Text = " "

        marcarTablaControl(boton)

        ganarPartida()
    End Sub

    Private Sub boton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                        Handles b66.Click, b65.Click, b64.Click, b63.Click, b61.Click, _
                        b56.Click, b51.Click, b35.Click, b31.Click, b25.Click, b24.Click, _
                        b21.Click, b13.Click, b12.Click, b11.Click, b42.Click
        'botones con texto -1-
        Dim boton As Button = CType(sender, Button)
        boton.BackColor = Color.White
        boton.Text = "1"

        marcarTablaControl(boton)

        ganarPartida()
    End Sub

    Private Sub boton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                        Handles b54.Click, b53.Click, b52.Click, b45.Click, b32.Click, b23.Click
        'botones con texto -2-
        Dim boton As Button = CType(sender, Button)
        boton.BackColor = Color.White
        boton.Text = "2"

        marcarTablaControl(boton)

        ganarPartida()
    End Sub

    Private Sub boton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b44.Click, b33.Click
        'botones con texto -3-
        Dim boton As Button = CType(sender, Button)
        boton.BackColor = Color.White
        boton.Text = "3"

        marcarTablaControl(boton)

        ganarPartida()
    End Sub


    Private Sub marcarTablaControl(ByVal boton As Button)
        ' el mombre del boton tiene la fila y la columna que me sirve para marcar la tabla
        Dim nombreBoton As String = boton.Name
        Dim f As Integer = CInt(nombreBoton.Substring(1, 1)) 'a partir de que posición, cuantos carateres
        Dim c As Integer = CInt(nombreBoton.Substring(2, 1))
        tablaControl(f, c) = 1
    End Sub


    Private Sub ganarPartida()

        Dim partidaGanada As Boolean = True

        For Each casilla As Integer In tablaControl
            If (casilla <> 5 And casilla <> 9 And casilla <> 1) Then
                partidaGanada = False    'quedan todavia 0 en la tabla
                Exit For
            End If
        Next
        If partidaGanada = True Then
            MsgBox("Enhorabuena es Vd. un campeon")
            etTitulo.Text = ""
            etTitulo.BackColor = Color.Aquamarine
            bSalir.Enabled = True
            bSalir.Focus()
            etTitulo.Text = " Txapeldun !!!"

            'bloquar el tablero
            For Each c As Control In Me.Controls
                If (c.TabIndex >= 1 And c.TabIndex < 37) Then
                    c.Enabled = False 'inhabilito todo el tablero
                End If
            Next

            'Podría modificar el valor de la propiedad a través de Controls(x).propiedad
            'For x = 1 To Controls.Count - 1
            '    If (Controls(x).TabIndex < 37) Then
            '        Controls(x).Enabled = False 'inhabilito todo el tablero
            '    End If
            'Next

        End If

        ''ojo! diferenciar los botones con el texto blanco de los sin texto, o sea, los de la bomba
        'If (b11.Text = "1" And b12.Text = "1" And b13.Text = "1" And b14.Text = " " And b15.Text = " " And b16.Text = " " And _
        '    b21.Text = "1" And b22.Text = "" And b23.Text = "2" And b24.Text = "1" And b25.Text = "1" And b26.Text = " " And _
        '    b31.Text = "1" And b32.Text = "2" And b33.Text = "3" And b34.Text = "" And b35.Text = "1" And b36.Text = " " And _
        '    b41.Text = " " And b42.Text = "1" And b43.Text = "" And b44.Text = "3" And b45.Text = "2" And b46.Text = " " And _
        '    b51.Text = "1" And b52.Text = "2" And b53.Text = "2" And b54.Text = "2" And b55.Text = "" And b56.Text = "1" And _
        '    b61.Text = "1" And b62.Text = "" And b63.Text = "1" And b64.Text = "1" And b65.Text = "1" And b66.Text = "1") Then

        '    MsgBox("Enhorabuena es Vd. un campeon")
        '    etTitulo.Text = ""
        '    etTitulo.BackColor = Color.Aquamarine
        '    bSalir.Enabled = True
        '    bSalir.Focus()
        '    etTitulo.Text = " Txapeldun !!!"

        '    'Los botones van desde TabIndex 1..36
        '    'Utilizo la propiedad Controls para recorrer en iteración todos los controles de un formulario,
        '    For Each c As Control In Me.Controls
        '        If (c.TabIndex >= 1 And c.TabIndex < 37) Then
        '            c.Enabled = False 'inhabilito todo el tablero
        '        End If
        '    Next

        '    'For x = 1 To Controls.Count - 1
        '    '    If (Controls(x).TabIndex < 37) Then
        '    '        Controls(x).Enabled = False 'inhabilito todo el tablero
        '    '    End If
        '    'Next
        'End If

    End Sub


    'Private Sub botones_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
    '                    Handles b66.Click, b65.Click, b64.Click, b63.Click, b62.Click, b61.Click, _
    '                            b56.Click, b55.Click, b54.Click, b53.Click, b52.Click, b51.Click, _
    '                            b46.Click, b45.Click, b44.Click, b43.Click, b42.Click, b41.Click, _
    '                            b36.Click, b35.Click, b34.Click, b33.Click, b32.Click, b31.Click, _
    '                            b26.Click, b25.Click, b24.Click, b23.Click, b22.Click, b21.Click, _
    '                            b16.Click, b15.Click, b14.Click, b13.Click, b12.Click, b11.Click

    '    Dim boton As Button = CType(sender, Button)

    '    Select Case boton.TabIndex           'obtengo el valor TabInex del control
    '        Case 1, 2, 3, 7, 10, 11, 13, 17, 20, 25, 30, 31, 33, 34, 35, 36
    '            '1
    '            boton.BackColor = Color.White
    '            boton.Text = "1"
    '            marcarTablaControl(boton)
    '            ganarPartida()
    '        Case 9, 14, 23, 26, 27, 28
    '            '2
    '            boton.BackColor = Color.White
    '            boton.Text = "2"
    '            marcarTablaControl(boton)
    '            ganarPartida()
    '        Case 15, 22
    '            '3
    '            boton.BackColor = Color.White
    '            boton.Text = "3"
    '            marcarTablaControl(boton)
    '            ganarPartida()
    '        Case 4, 5, 6, 12, 18, 19, 24
    '            'blanco
    '            boton.BackColor = Color.White
    '            boton.Text = " "
    '            marcarTablaControl(boton)
    '            ganarPartida()
    '        Case 8, 16, 21, 29, 32
    '            'bombas
    '            boton.BackColor = Color.Red
    '            boton.Text = "@"
    '            etSalir.Text = "Game Over"
    '            bSalir.Enabled = True
    '        Case Else
    '            'blancos
    '            boton.BackColor = Color.White
    '            marcarTablaControl(boton)
    '            ganarPartida()
    '    End Select
    'End Sub


End Class
