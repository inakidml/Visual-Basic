﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.etTitulo = New System.Windows.Forms.Label()
        Me.b11 = New System.Windows.Forms.Button()
        Me.b12 = New System.Windows.Forms.Button()
        Me.b13 = New System.Windows.Forms.Button()
        Me.b14 = New System.Windows.Forms.Button()
        Me.b15 = New System.Windows.Forms.Button()
        Me.b16 = New System.Windows.Forms.Button()
        Me.b21 = New System.Windows.Forms.Button()
        Me.b22 = New System.Windows.Forms.Button()
        Me.b23 = New System.Windows.Forms.Button()
        Me.b24 = New System.Windows.Forms.Button()
        Me.b25 = New System.Windows.Forms.Button()
        Me.b26 = New System.Windows.Forms.Button()
        Me.b31 = New System.Windows.Forms.Button()
        Me.b32 = New System.Windows.Forms.Button()
        Me.b33 = New System.Windows.Forms.Button()
        Me.b34 = New System.Windows.Forms.Button()
        Me.b35 = New System.Windows.Forms.Button()
        Me.b36 = New System.Windows.Forms.Button()
        Me.b41 = New System.Windows.Forms.Button()
        Me.b42 = New System.Windows.Forms.Button()
        Me.b43 = New System.Windows.Forms.Button()
        Me.b44 = New System.Windows.Forms.Button()
        Me.b45 = New System.Windows.Forms.Button()
        Me.b46 = New System.Windows.Forms.Button()
        Me.b51 = New System.Windows.Forms.Button()
        Me.b52 = New System.Windows.Forms.Button()
        Me.b53 = New System.Windows.Forms.Button()
        Me.b54 = New System.Windows.Forms.Button()
        Me.b55 = New System.Windows.Forms.Button()
        Me.b56 = New System.Windows.Forms.Button()
        Me.b61 = New System.Windows.Forms.Button()
        Me.b62 = New System.Windows.Forms.Button()
        Me.b63 = New System.Windows.Forms.Button()
        Me.b64 = New System.Windows.Forms.Button()
        Me.b65 = New System.Windows.Forms.Button()
        Me.b66 = New System.Windows.Forms.Button()
        Me.bSalir = New System.Windows.Forms.Button()
        Me.etSalir = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'etTitulo
        '
        Me.etTitulo.AutoSize = True
        Me.etTitulo.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etTitulo.Location = New System.Drawing.Point(95, 37)
        Me.etTitulo.Name = "etTitulo"
        Me.etTitulo.Size = New System.Drawing.Size(195, 29)
        Me.etTitulo.TabIndex = 0
        Me.etTitulo.Text = "BUSCAMINAS"
        '
        'b11
        '
        Me.b11.Location = New System.Drawing.Point(96, 103)
        Me.b11.Name = "b11"
        Me.b11.Size = New System.Drawing.Size(32, 32)
        Me.b11.TabIndex = 1
        Me.b11.UseVisualStyleBackColor = True
        '
        'b12
        '
        Me.b12.Location = New System.Drawing.Point(128, 103)
        Me.b12.Name = "b12"
        Me.b12.Size = New System.Drawing.Size(32, 32)
        Me.b12.TabIndex = 2
        Me.b12.UseVisualStyleBackColor = True
        '
        'b13
        '
        Me.b13.Location = New System.Drawing.Point(160, 103)
        Me.b13.Name = "b13"
        Me.b13.Size = New System.Drawing.Size(32, 32)
        Me.b13.TabIndex = 3
        Me.b13.UseVisualStyleBackColor = True
        '
        'b14
        '
        Me.b14.Location = New System.Drawing.Point(192, 103)
        Me.b14.Name = "b14"
        Me.b14.Size = New System.Drawing.Size(32, 32)
        Me.b14.TabIndex = 4
        Me.b14.UseVisualStyleBackColor = True
        '
        'b15
        '
        Me.b15.Location = New System.Drawing.Point(224, 103)
        Me.b15.Name = "b15"
        Me.b15.Size = New System.Drawing.Size(32, 32)
        Me.b15.TabIndex = 5
        Me.b15.UseVisualStyleBackColor = True
        '
        'b16
        '
        Me.b16.Location = New System.Drawing.Point(256, 103)
        Me.b16.Name = "b16"
        Me.b16.Size = New System.Drawing.Size(32, 32)
        Me.b16.TabIndex = 6
        Me.b16.UseVisualStyleBackColor = True
        '
        'b21
        '
        Me.b21.Location = New System.Drawing.Point(96, 135)
        Me.b21.Name = "b21"
        Me.b21.Size = New System.Drawing.Size(32, 32)
        Me.b21.TabIndex = 7
        Me.b21.UseVisualStyleBackColor = True
        '
        'b22
        '
        Me.b22.Location = New System.Drawing.Point(128, 135)
        Me.b22.Name = "b22"
        Me.b22.Size = New System.Drawing.Size(32, 32)
        Me.b22.TabIndex = 8
        Me.b22.UseVisualStyleBackColor = True
        '
        'b23
        '
        Me.b23.Location = New System.Drawing.Point(160, 135)
        Me.b23.Name = "b23"
        Me.b23.Size = New System.Drawing.Size(32, 32)
        Me.b23.TabIndex = 9
        Me.b23.UseVisualStyleBackColor = True
        '
        'b24
        '
        Me.b24.Location = New System.Drawing.Point(192, 135)
        Me.b24.Name = "b24"
        Me.b24.Size = New System.Drawing.Size(32, 32)
        Me.b24.TabIndex = 10
        Me.b24.UseVisualStyleBackColor = True
        '
        'b25
        '
        Me.b25.Location = New System.Drawing.Point(224, 135)
        Me.b25.Name = "b25"
        Me.b25.Size = New System.Drawing.Size(32, 32)
        Me.b25.TabIndex = 11
        Me.b25.UseVisualStyleBackColor = True
        '
        'b26
        '
        Me.b26.Location = New System.Drawing.Point(256, 135)
        Me.b26.Name = "b26"
        Me.b26.Size = New System.Drawing.Size(32, 32)
        Me.b26.TabIndex = 12
        Me.b26.UseVisualStyleBackColor = True
        '
        'b31
        '
        Me.b31.Location = New System.Drawing.Point(96, 167)
        Me.b31.Name = "b31"
        Me.b31.Size = New System.Drawing.Size(32, 32)
        Me.b31.TabIndex = 13
        Me.b31.UseVisualStyleBackColor = True
        '
        'b32
        '
        Me.b32.Location = New System.Drawing.Point(128, 167)
        Me.b32.Name = "b32"
        Me.b32.Size = New System.Drawing.Size(32, 32)
        Me.b32.TabIndex = 14
        Me.b32.UseVisualStyleBackColor = True
        '
        'b33
        '
        Me.b33.Location = New System.Drawing.Point(160, 167)
        Me.b33.Name = "b33"
        Me.b33.Size = New System.Drawing.Size(32, 32)
        Me.b33.TabIndex = 15
        Me.b33.UseVisualStyleBackColor = True
        '
        'b34
        '
        Me.b34.Location = New System.Drawing.Point(192, 167)
        Me.b34.Name = "b34"
        Me.b34.Size = New System.Drawing.Size(32, 32)
        Me.b34.TabIndex = 16
        Me.b34.UseVisualStyleBackColor = True
        '
        'b35
        '
        Me.b35.Location = New System.Drawing.Point(224, 167)
        Me.b35.Name = "b35"
        Me.b35.Size = New System.Drawing.Size(32, 32)
        Me.b35.TabIndex = 17
        Me.b35.UseVisualStyleBackColor = True
        '
        'b36
        '
        Me.b36.Location = New System.Drawing.Point(256, 167)
        Me.b36.Name = "b36"
        Me.b36.Size = New System.Drawing.Size(32, 32)
        Me.b36.TabIndex = 18
        Me.b36.UseVisualStyleBackColor = True
        '
        'b41
        '
        Me.b41.Location = New System.Drawing.Point(96, 199)
        Me.b41.Name = "b41"
        Me.b41.Size = New System.Drawing.Size(32, 32)
        Me.b41.TabIndex = 19
        Me.b41.UseVisualStyleBackColor = True
        '
        'b42
        '
        Me.b42.Location = New System.Drawing.Point(128, 199)
        Me.b42.Name = "b42"
        Me.b42.Size = New System.Drawing.Size(32, 32)
        Me.b42.TabIndex = 20
        Me.b42.UseVisualStyleBackColor = True
        '
        'b43
        '
        Me.b43.Location = New System.Drawing.Point(160, 199)
        Me.b43.Name = "b43"
        Me.b43.Size = New System.Drawing.Size(32, 32)
        Me.b43.TabIndex = 21
        Me.b43.UseVisualStyleBackColor = True
        '
        'b44
        '
        Me.b44.Location = New System.Drawing.Point(192, 199)
        Me.b44.Name = "b44"
        Me.b44.Size = New System.Drawing.Size(32, 32)
        Me.b44.TabIndex = 22
        Me.b44.UseVisualStyleBackColor = True
        '
        'b45
        '
        Me.b45.Location = New System.Drawing.Point(224, 199)
        Me.b45.Name = "b45"
        Me.b45.Size = New System.Drawing.Size(32, 32)
        Me.b45.TabIndex = 23
        Me.b45.UseVisualStyleBackColor = True
        '
        'b46
        '
        Me.b46.Location = New System.Drawing.Point(256, 199)
        Me.b46.Name = "b46"
        Me.b46.Size = New System.Drawing.Size(32, 32)
        Me.b46.TabIndex = 24
        Me.b46.UseVisualStyleBackColor = True
        '
        'b51
        '
        Me.b51.Location = New System.Drawing.Point(96, 231)
        Me.b51.Name = "b51"
        Me.b51.Size = New System.Drawing.Size(32, 32)
        Me.b51.TabIndex = 25
        Me.b51.UseVisualStyleBackColor = True
        '
        'b52
        '
        Me.b52.Location = New System.Drawing.Point(128, 231)
        Me.b52.Name = "b52"
        Me.b52.Size = New System.Drawing.Size(32, 32)
        Me.b52.TabIndex = 26
        Me.b52.UseVisualStyleBackColor = True
        '
        'b53
        '
        Me.b53.Location = New System.Drawing.Point(160, 231)
        Me.b53.Name = "b53"
        Me.b53.Size = New System.Drawing.Size(32, 32)
        Me.b53.TabIndex = 27
        Me.b53.UseVisualStyleBackColor = True
        '
        'b54
        '
        Me.b54.Location = New System.Drawing.Point(192, 231)
        Me.b54.Name = "b54"
        Me.b54.Size = New System.Drawing.Size(32, 32)
        Me.b54.TabIndex = 28
        Me.b54.UseVisualStyleBackColor = True
        '
        'b55
        '
        Me.b55.Location = New System.Drawing.Point(224, 231)
        Me.b55.Name = "b55"
        Me.b55.Size = New System.Drawing.Size(32, 32)
        Me.b55.TabIndex = 29
        Me.b55.UseVisualStyleBackColor = True
        '
        'b56
        '
        Me.b56.Location = New System.Drawing.Point(256, 231)
        Me.b56.Name = "b56"
        Me.b56.Size = New System.Drawing.Size(32, 32)
        Me.b56.TabIndex = 30
        Me.b56.UseVisualStyleBackColor = True
        '
        'b61
        '
        Me.b61.Location = New System.Drawing.Point(96, 263)
        Me.b61.Name = "b61"
        Me.b61.Size = New System.Drawing.Size(32, 32)
        Me.b61.TabIndex = 31
        Me.b61.UseVisualStyleBackColor = True
        '
        'b62
        '
        Me.b62.Location = New System.Drawing.Point(128, 263)
        Me.b62.Name = "b62"
        Me.b62.Size = New System.Drawing.Size(32, 32)
        Me.b62.TabIndex = 32
        Me.b62.UseVisualStyleBackColor = True
        '
        'b63
        '
        Me.b63.Location = New System.Drawing.Point(160, 263)
        Me.b63.Name = "b63"
        Me.b63.Size = New System.Drawing.Size(32, 32)
        Me.b63.TabIndex = 33
        Me.b63.UseVisualStyleBackColor = True
        '
        'b64
        '
        Me.b64.Location = New System.Drawing.Point(192, 263)
        Me.b64.Name = "b64"
        Me.b64.Size = New System.Drawing.Size(32, 32)
        Me.b64.TabIndex = 34
        Me.b64.UseVisualStyleBackColor = True
        '
        'b65
        '
        Me.b65.Location = New System.Drawing.Point(224, 263)
        Me.b65.Name = "b65"
        Me.b65.Size = New System.Drawing.Size(32, 32)
        Me.b65.TabIndex = 35
        Me.b65.UseVisualStyleBackColor = True
        '
        'b66
        '
        Me.b66.Location = New System.Drawing.Point(256, 263)
        Me.b66.Name = "b66"
        Me.b66.Size = New System.Drawing.Size(32, 32)
        Me.b66.TabIndex = 36
        Me.b66.UseVisualStyleBackColor = True
        '
        'bSalir
        '
        Me.bSalir.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bSalir.Location = New System.Drawing.Point(96, 341)
        Me.bSalir.Name = "bSalir"
        Me.bSalir.Size = New System.Drawing.Size(192, 45)
        Me.bSalir.TabIndex = 37
        Me.bSalir.Text = "Salir"
        Me.bSalir.UseVisualStyleBackColor = True
        '
        'etSalir
        '
        Me.etSalir.AutoSize = True
        Me.etSalir.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etSalir.ForeColor = System.Drawing.Color.Cyan
        Me.etSalir.Location = New System.Drawing.Point(104, 301)
        Me.etSalir.Name = "etSalir"
        Me.etSalir.Size = New System.Drawing.Size(0, 35)
        Me.etSalir.TabIndex = 38
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 398)
        Me.ControlBox = False
        Me.Controls.Add(Me.etSalir)
        Me.Controls.Add(Me.bSalir)
        Me.Controls.Add(Me.b66)
        Me.Controls.Add(Me.b65)
        Me.Controls.Add(Me.b64)
        Me.Controls.Add(Me.b63)
        Me.Controls.Add(Me.b62)
        Me.Controls.Add(Me.b61)
        Me.Controls.Add(Me.b56)
        Me.Controls.Add(Me.b55)
        Me.Controls.Add(Me.b54)
        Me.Controls.Add(Me.b53)
        Me.Controls.Add(Me.b52)
        Me.Controls.Add(Me.b51)
        Me.Controls.Add(Me.b46)
        Me.Controls.Add(Me.b45)
        Me.Controls.Add(Me.b44)
        Me.Controls.Add(Me.b43)
        Me.Controls.Add(Me.b42)
        Me.Controls.Add(Me.b41)
        Me.Controls.Add(Me.b36)
        Me.Controls.Add(Me.b35)
        Me.Controls.Add(Me.b34)
        Me.Controls.Add(Me.b33)
        Me.Controls.Add(Me.b32)
        Me.Controls.Add(Me.b31)
        Me.Controls.Add(Me.b26)
        Me.Controls.Add(Me.b25)
        Me.Controls.Add(Me.b24)
        Me.Controls.Add(Me.b23)
        Me.Controls.Add(Me.b22)
        Me.Controls.Add(Me.b21)
        Me.Controls.Add(Me.b16)
        Me.Controls.Add(Me.b15)
        Me.Controls.Add(Me.b14)
        Me.Controls.Add(Me.b13)
        Me.Controls.Add(Me.b12)
        Me.Controls.Add(Me.b11)
        Me.Controls.Add(Me.etTitulo)
        Me.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents etTitulo As System.Windows.Forms.Label
    Friend WithEvents b11 As System.Windows.Forms.Button
    Friend WithEvents b12 As System.Windows.Forms.Button
    Friend WithEvents b13 As System.Windows.Forms.Button
    Friend WithEvents b14 As System.Windows.Forms.Button
    Friend WithEvents b15 As System.Windows.Forms.Button
    Friend WithEvents b16 As System.Windows.Forms.Button
    Friend WithEvents b21 As System.Windows.Forms.Button
    Friend WithEvents b22 As System.Windows.Forms.Button
    Friend WithEvents b23 As System.Windows.Forms.Button
    Friend WithEvents b24 As System.Windows.Forms.Button
    Friend WithEvents b25 As System.Windows.Forms.Button
    Friend WithEvents b26 As System.Windows.Forms.Button
    Friend WithEvents b31 As System.Windows.Forms.Button
    Friend WithEvents b32 As System.Windows.Forms.Button
    Friend WithEvents b33 As System.Windows.Forms.Button
    Friend WithEvents b34 As System.Windows.Forms.Button
    Friend WithEvents b35 As System.Windows.Forms.Button
    Friend WithEvents b36 As System.Windows.Forms.Button
    Friend WithEvents b41 As System.Windows.Forms.Button
    Friend WithEvents b42 As System.Windows.Forms.Button
    Friend WithEvents b43 As System.Windows.Forms.Button
    Friend WithEvents b44 As System.Windows.Forms.Button
    Friend WithEvents b45 As System.Windows.Forms.Button
    Friend WithEvents b46 As System.Windows.Forms.Button
    Friend WithEvents b51 As System.Windows.Forms.Button
    Friend WithEvents b52 As System.Windows.Forms.Button
    Friend WithEvents b53 As System.Windows.Forms.Button
    Friend WithEvents b54 As System.Windows.Forms.Button
    Friend WithEvents b55 As System.Windows.Forms.Button
    Friend WithEvents b56 As System.Windows.Forms.Button
    Friend WithEvents b61 As System.Windows.Forms.Button
    Friend WithEvents b62 As System.Windows.Forms.Button
    Friend WithEvents b63 As System.Windows.Forms.Button
    Friend WithEvents b64 As System.Windows.Forms.Button
    Friend WithEvents b65 As System.Windows.Forms.Button
    Friend WithEvents b66 As System.Windows.Forms.Button
    Friend WithEvents bSalir As System.Windows.Forms.Button
    Friend WithEvents etSalir As System.Windows.Forms.Label

End Class
