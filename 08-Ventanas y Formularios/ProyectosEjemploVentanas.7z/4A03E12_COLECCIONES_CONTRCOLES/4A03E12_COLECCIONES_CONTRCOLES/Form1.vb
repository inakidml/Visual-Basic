﻿Public Class Form1

    Private Sub etiquetas()

        For x = 0 To Controls.Count - 1
            If (TypeOf Controls(x) Is Label) Then  'si es del tipo etiqueta
                If Controls(x).Enabled = True Then
                    Controls(x).ForeColor = Color.Red
                End If
            End If
        Next

    End Sub

    Private Sub botones()

        For x = 0 To Controls.Count - 1
            If (TypeOf Controls(x) Is Button) Then  'si es del tipo Boton
                Controls(x).BackColor = Color.Blue
            End If
        Next

    End Sub


    Private Sub cajas()

        For x = 0 To Controls.Count - 1
            If (TypeOf Controls(x) Is TextBox) Then  'si es del tipo caja de texto
                Controls(x).BackColor = Color.Green
            End If
        Next

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        botones()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim at As New Point
        at = TextBox1.Location


        Controls.Remove(TextBox1)
        Dim att As Label = Nothing
        att = New Label
        att.Location = New Point(at)
        att.Name = "etiquetas"
        att.Text = "Nada"

        cajas()
        Controls.Add(att)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        etiquetas()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For x = 0 To Controls.Count - 1
            If (TypeOf Controls(x) Is TextBox) Then  'si es del tipo caja de texto
                Controls(x).Enabled = False
            End If
        Next
    End Sub

    Private Sub AbrirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AbrirToolStripMenuItem.Click

    End Sub

    Private Sub AbrirToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AbrirToolStripMenuItem1.Click
        MsgBox("Que quieres abrir?")
    End Sub
End Class
