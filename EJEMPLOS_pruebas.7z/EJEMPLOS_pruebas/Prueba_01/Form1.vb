﻿'espacios de nombres que se van a utilizar para obtener las  ( VB pag282)
Imports System                      'clases fundamentales
Imports System.Windows.Forms        'clase Form 
Imports System.Drawing              'Objetos gráficos

Public Class Form1

    ' Atributos y métodos
    Public Sub New()

        MyBase.New()  'Invoca al constructor de la clase base

        ' Llamada necesaria para el diseñador.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub


End Class
